<?php
/**
 * Plugin Name: Axxiom AEO Schema
 * Description: AEO plumbing for Axxiom brand sites: JSON-LD output from post meta, robots.txt with sitemap + LLM policy, generated /llms.txt, the IndexNow key file, GA4 phone-click conversion tracking, and noindex for schema carrier pages (Axxiom AEO Automation Platform).
 * Version: 1.4.0
 * Author: Axxiom Elevator
 *
 * Install: copy to wp-content/mu-plugins/axxiom-aeo-schema.php on each brand site.
 * NOTE: delete any physical robots.txt / llms.txt files at the web root — a
 * physical file is served before WordPress runs, which hides these endpoints.
 */

// Shared across all Axxiom brand sites; each host serves it at /<key>.txt,
// which is what makes IndexNow submissions for that host valid. Must match
// INDEXNOW_KEY on the AEO backend.
define('AXXIOM_INDEXNOW_KEY', 'c550d35adee3985871ee6e39bd7f8e35');

/**
 * Allow the Axxiom backend to write schema via WordPress REST API (meta.aeo_schema_json).
 */
add_action('init', function () {
    $args = [
        'type' => 'string',
        'single' => true,
        'show_in_rest' => true,
        'auth_callback' => function () {
            return current_user_can('edit_posts');
        },
    ];

    register_post_meta('post', 'aeo_schema_json', $args);
    register_post_meta('page', 'aeo_schema_json', $args);
});

add_action('wp_head', function () {
    if (!is_singular()) {
        return;
    }
    $post_id = get_queried_object_id();
    if (!$post_id) {
        return;
    }
    $schema = get_post_meta($post_id, 'aeo_schema_json', true);
    if (!$schema || !is_string($schema)) {
        return;
    }
    $schema = trim($schema);
    if ($schema === '') {
        return;
    }
    // Basic safety: only output if it looks like JSON object/array.
    if ($schema[0] !== '{' && $schema[0] !== '[') {
        return;
    }
    // '</' inside the JSON (e.g. '</script>' in a string) would end the block
    // early; '<\/' is a valid JSON escape, so the JSON-LD stays parseable.
    $schema = str_replace('</', '<\/', $schema);
    echo '<script type="application/ld+json">' . $schema . '</script>' . "\n";
}, 5);

/**
 * Schema carrier pages (slug "schema-...", created by the AEO platform to hold
 * brand-level JSON-LD) are near-empty, so keep them out of search: noindex,
 * and out of the sitemaps and llms.txt. The platform also asks Yoast for
 * noindex through the REST API, but Yoast's meta keys are not writable there,
 * so that request never took effect.
 */
function axxiom_aeo_is_schema_carrier($post = null) {
    $post = get_post($post);
    return $post
        && $post->post_type === 'page'
        && strpos($post->post_name, 'schema-') === 0
        && get_post_meta($post->ID, 'aeo_schema_json', true);
}

function axxiom_aeo_schema_carrier_ids() {
    $ids = [];
    $pages = get_posts([
        'post_type' => 'page',
        'post_status' => 'publish',
        'numberposts' => 200,
        'fields' => 'ids',
        'meta_key' => 'aeo_schema_json',
    ]);
    foreach ($pages as $id) {
        if (strpos(get_post_field('post_name', $id), 'schema-') === 0) {
            $ids[] = $id;
        }
    }
    return $ids;
}

add_filter('wp_robots', function ($robots) {
    if (is_singular('page') && axxiom_aeo_is_schema_carrier(get_queried_object_id())) {
        unset($robots['index']);
        $robots['noindex'] = true;
        $robots['follow'] = true;
    }
    return $robots;
}, 20);

// Yoast prints its own robots meta tag.
add_filter('wpseo_robots', function ($robots) {
    if (is_singular('page') && axxiom_aeo_is_schema_carrier(get_queried_object_id())) {
        return 'noindex, follow';
    }
    return $robots;
});

add_filter('wpseo_exclude_from_sitemap_by_post_ids', function ($ids) {
    return array_merge((array) $ids, axxiom_aeo_schema_carrier_ids());
});

// WordPress core sitemaps, for a site without Yoast.
add_filter('wp_sitemaps_posts_query_args', function ($args, $post_type) {
    if ($post_type === 'page') {
        $args['post__not_in'] = array_merge($args['post__not_in'] ?? [], axxiom_aeo_schema_carrier_ids());
    }
    return $args;
}, 10, 2);

/**
 * The sitemap URL for this site: Yoast's index when Yoast is active, else
 * WordPress core's wp-sitemap.xml.
 */
function axxiom_aeo_sitemap_url() {
    if (defined('WPSEO_VERSION')) {
        return home_url('/sitemap_index.xml');
    }
    return home_url('/wp-sitemap.xml');
}

/**
 * robots.txt: allow everything (including AI crawlers), declare the sitemap,
 * and point LLMs at /llms.txt. Only applies to WordPress's virtual
 * robots.txt — delete any physical robots.txt file so this takes effect.
 */
add_filter('robots_txt', function ($output) {
    $lines = [
        'User-agent: *',
        'Allow: /',
        '',
        'LLM-Policy: ' . home_url('/llms.txt'),
        'Sitemap: ' . axxiom_aeo_sitemap_url(),
    ];
    return trim($output) === '' ? implode("\n", $lines) . "\n"
        : rtrim($output) . "\n\n" . implode("\n", array_slice($lines, 3)) . "\n";
});

/**
 * WP Engine/Cloudflare serve unknown root *.txt requests from the static
 * layer — they never reach WordPress (only allowlisted names like robots.txt
 * and llms.txt pass through). So the IndexNow key file must exist as a
 * PHYSICAL file at the web root. Write it on admin page loads (i.e. the
 * first time anyone opens wp-admin after installing this version). Also
 * write a physical robots.txt, but ONLY when the existing one is missing or
 * empty — several sites carry an empty physical robots.txt that masks
 * WordPress's virtual one, and an empty robots.txt declares no sitemap.
 */
add_action('admin_init', function () {
    $key_path = ABSPATH . AXXIOM_INDEXNOW_KEY . '.txt';
    if (!file_exists($key_path)) {
        @file_put_contents($key_path, AXXIOM_INDEXNOW_KEY);
    }

    $robots_path = ABSPATH . 'robots.txt';
    $existing = file_exists($robots_path) ? trim((string) @file_get_contents($robots_path)) : null;
    if ($existing === '' || ($existing === null && !file_exists($robots_path))) {
        $robots = "User-agent: *\nAllow: /\n\n"
            . 'LLM-Policy: ' . home_url('/llms.txt') . "\n"
            . 'Sitemap: ' . axxiom_aeo_sitemap_url() . "\n";
        @file_put_contents($robots_path, $robots);
    }
});

/**
 * GA4 phone-click conversion tracking: fires a `phone_call_click` event when
 * any tel: link is clicked (the AEO CTA buttons, header phone numbers, etc.).
 * Works with gtag or GTM (dataLayer); silently does nothing if neither is on
 * the page. Mark `phone_call_click` as a key event in GA4 to count it as a
 * conversion — the AEO platform's conversion KPIs read exactly that.
 */
add_action('wp_footer', function () {
    ?>
    <script id="axxiom-aeo-telclick">
    document.addEventListener('click', function (e) {
        var a = e.target && e.target.closest ? e.target.closest('a[href^="tel:"]') : null;
        if (!a) return;
        var payload = {
            phone_number: (a.getAttribute('href') || '').replace('tel:', ''),
            link_text: (a.textContent || '').trim().slice(0, 100),
            page_location: window.location.href
        };
        if (typeof window.gtag === 'function') {
            window.gtag('event', 'phone_call_click', payload);
        } else if (window.dataLayer && window.dataLayer.push) {
            payload.event = 'phone_call_click';
            window.dataLayer.push(payload);
        }
    }, true);
    </script>
    <?php
});

/**
 * Serve /llms.txt (generated) and /<indexnow-key>.txt. Handled before
 * template resolution so no theme/permalink setup is required. A physical
 * file with the same name at the web root wins (served before WP) — that's
 * fine, it just overrides the generated version.
 */
add_action('parse_request', function ($wp) {
    $path = trim(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?? '', '/');

    if ($path === AXXIOM_INDEXNOW_KEY . '.txt') {
        header('Content-Type: text/plain; charset=utf-8');
        echo AXXIOM_INDEXNOW_KEY;
        exit;
    }

    if ($path !== 'llms.txt') {
        return;
    }

    header('Content-Type: text/plain; charset=utf-8');
    $name = get_bloginfo('name');
    $desc = get_bloginfo('description');

    echo "# {$name}\n\n";
    if ($desc) {
        echo "> {$desc}\n\n";
    }
    echo "> Independent elevator service company. Content below answers common\n";
    echo "> elevator maintenance, repair, modernization, inspection, and\n";
    echo "> compliance questions for our service markets.\n\n";
    echo "Sitemap: " . axxiom_aeo_sitemap_url() . "\n\n";

    echo "## Key pages\n\n";
    $pages = get_pages(['sort_column' => 'menu_order', 'number' => 15, 'exclude' => axxiom_aeo_schema_carrier_ids()]);
    foreach ($pages as $p) {
        echo '- [' . wp_strip_all_tags(get_the_title($p)) . '](' . get_permalink($p) . ")\n";
    }

    echo "\n## Articles\n\n";
    $posts = get_posts(['numberposts' => 100, 'post_status' => 'publish']);
    foreach ($posts as $p) {
        echo '- [' . wp_strip_all_tags(get_the_title($p)) . '](' . get_permalink($p) . ")\n";
    }
    exit;
});
